#!/bin/bash

sort $1 >  sorted_list
