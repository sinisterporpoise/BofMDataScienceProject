#!/usr/bin/env python3

try:
	with open("output_file3.txt", "r") as f:
	     data = f.read()
except:
	     print ("File I/O Error.")

data_2  = data.split(" ")

try:
	with open("output_list.lst", "w") as g:
		for item in data_2:
			g.write(item.lower())
			g.write("\n");
except:
	print("Error writing to file")
